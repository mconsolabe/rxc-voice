import * as WebService from "./WebService";

export { WebService };
