// PRODUCTION URLS
//export const API = "https://voiceapi.radicalxchange.org";
//export const WEB = "https://voice.radicalxchange.org";

// LOCAL URLS
export const API = "http://localhost:8000";
export const WEB = "http://localhost:4000";
