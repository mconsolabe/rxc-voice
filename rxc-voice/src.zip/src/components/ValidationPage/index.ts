import ValidationPage from "./ValidationPage";

export default ValidationPage;
