import ForgotPassword from "./ForgotPassword";

export default ForgotPassword;
