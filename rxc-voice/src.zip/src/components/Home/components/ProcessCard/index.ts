import ProcessCard from "./ProcessCard";

export default ProcessCard;
