import CreateEvent from "./CreateGroup";

export default CreateEvent;
