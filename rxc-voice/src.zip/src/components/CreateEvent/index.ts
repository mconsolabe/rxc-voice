import CreateEvent from "./CreateEvent";

export default CreateEvent;
