import ManageEvents from "./ManageEvents";

export default ManageEvents;
