import EventManager from "./EventManager";

export default EventManager;
