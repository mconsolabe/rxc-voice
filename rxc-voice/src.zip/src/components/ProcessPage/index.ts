import ProcessPage from "./ProcessPage";

export default ProcessPage;
