import DeliberationPage from "./DeliberationPage";

export default DeliberationPage;
