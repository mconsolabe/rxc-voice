import RemainingCredits from "./RemainingCredits";

export default RemainingCredits;
