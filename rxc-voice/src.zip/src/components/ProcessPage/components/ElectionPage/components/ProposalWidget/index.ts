import ProposalWidget from "./ProposalWidget";

export default ProposalWidget;
