import ProposalResults from "./ProposalResults";

export default ProposalResults;
