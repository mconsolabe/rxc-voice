import ElectionPage from "./ElectionPage";

export default ElectionPage;
