import TransferModal from "./TransferModal";

export default TransferModal;
