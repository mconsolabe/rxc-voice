import DelegateCard from "./DelegateCard";

export default DelegateCard;
