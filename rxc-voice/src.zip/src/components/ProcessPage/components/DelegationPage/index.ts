import DelegationPage from "./DelegationPage";

export default DelegationPage;
