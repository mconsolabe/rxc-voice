export interface ProcessPageRouteParams {
  processId: string,
  stageId: string,
}
