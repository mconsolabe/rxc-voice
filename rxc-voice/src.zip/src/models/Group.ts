export interface Group {
  id: number,
  name: string,
  users: string[],
}
