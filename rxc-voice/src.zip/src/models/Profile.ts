export interface Profile {
  id: number,
  is_verified: boolean,
  user: any,
  public_username: string,
  oauth_provider: string,
}
