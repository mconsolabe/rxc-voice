export enum BgColor {
  Yellow = "var(--yellowColor)",
  White = "var(--whiteColor)",
}
