export enum VerificationMethod {
  Github = "git",
  Twitter = "twt",
  Application = "app",
}
