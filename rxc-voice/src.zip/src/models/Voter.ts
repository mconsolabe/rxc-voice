export interface Voter {
  id: number,
  email: string,
  password: string,
}
