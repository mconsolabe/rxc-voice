export interface Vote {
  id: number,
  sender: string,
  proposal: number,
  amount: number,
  date: string,
}
